class Config:
    SECRET_KEY = 'keyy'  # Replace with your own secret key
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USERNAME = 'proconnect.ttmoon@gmail.com'
    MAIL_PASSWORD = 'xvxt yabx zxpk tkki'
    MAIL_DEFAULT_SENDER = 'proconnect.ttmoon@gmail.com'
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
