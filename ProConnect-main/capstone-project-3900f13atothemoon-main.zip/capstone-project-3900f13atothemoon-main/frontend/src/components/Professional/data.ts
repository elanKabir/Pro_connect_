export const ProfessionalLocation = [
  'New South Wales',
  'Queensland',
  'South Australia',
  'Tasmania',
  'Victoria',
  'Western Australia',
  'Australian Capital Territory',
  'Northern Territory',
];

export const ProfessionalRatings = [
  '1 Star',
  '2 Stars',
  '3 Stars',
  '4 Stars',
  '5 Stars',
];

export const ProfessionalSortBy = ['Highest Rated', 'Lowest Rated'];
