

export const ABN_LOOK_UP_URL =
  'https://abr.business.gov.au/json/AbnDetails.aspx';
export const ABN_GUID = '5bb02052-2d9b-412e-8ecb-f34f963c76a5';
