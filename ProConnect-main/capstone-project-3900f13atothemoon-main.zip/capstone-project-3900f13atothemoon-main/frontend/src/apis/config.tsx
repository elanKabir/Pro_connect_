const BACKEND_URL = 'http://127.0.0.1';
const BACKEND_PORT = '5001';
export const BACKEND_API_URL = `${BACKEND_URL}:${BACKEND_PORT}`;
